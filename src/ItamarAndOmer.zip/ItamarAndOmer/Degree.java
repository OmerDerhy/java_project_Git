package ItamarAndOmer;

public enum Degree {
    BACHELOR, MASTER, PHD, PROFESSOR;

    @Override
    public String toString() {
        return switch (this) {
            case BACHELOR -> "Bachelor";
            case MASTER -> "Master";
            case PHD -> "PhD";
            case PROFESSOR -> "Professor";
        };
    }
}